#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    string inputFileName, outputFileName;

    // Get the input and output file names from the user
    cout << "Enter the input file name: ";
    cin >> inputFileName;
    cout << "Enter the output file name: ";
    cin >> outputFileName;

    // Open the input file
    ifstream inputFile(inputFileName);
    if (!inputFile) {
        cerr << "Error opening the input file." << endl;
        return 1;
    }

    // Open the output file
    ofstream outputFile(outputFileName);
    if (!outputFile) {
        cerr << "Error opening the output file." << endl;
        return 1;
    }

    char next;
    while (inputFile.get(next)) {
        if (next == 'C') {
            outputFile << "C++";
        } else {
            outputFile.put(next);
        }
    }

    // Close the files
    inputFile.close();
    outputFile.close();

    cout << "File processing completed successfully." << endl;

    return 0;
}
