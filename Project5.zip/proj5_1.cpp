#include <iostream>
#include <iomanip>
#include "DivSales.h"

using namespace std;

int main() {
    const int NUM_DIVISIONS = 6;
    DivSales divisions[NUM_DIVISIONS];

    // Input sales data for each division
    for (int i = 0; i < NUM_DIVISIONS; i++) {
        double q1, q2, q3, q4;
        cout << "Enter sales for Division " << (i + 1) << " (Q1 Q2 Q3 Q4): ";
        cin >> q1 >> q2 >> q3 >> q4;
        divisions[i].setSales(q1, q2, q3, q4);
    }

    // Display the sales table
    cout << fixed << setprecision(2);
    cout << "Sales Table:" << endl;
    cout << "Division\tQ1\t\tQ2\t\tQ3\t\tQ4" << endl;
    for (int i = 0; i < NUM_DIVISIONS; i++) {
        cout << (i + 1) << "\t\t";
        for (int q = 0; q < 4; q++) {
            cout << divisions[i].getSales(q) << "\t\t";
        }
        cout << endl;
    }

    // Display total corporate sales
    cout << "Total Corporate Sales: " << DivSales::getTotalSales() << endl;

    return 0;
}
