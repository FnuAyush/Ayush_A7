#ifndef DIVSALES_H
#define DIVSALES_H

class DivSales {
private:
    double sales[4]; // Sales for each quarter
    static double totalSales; // Total sales for all divisions

public:
    DivSales(); // Default constructor
    void setSales(double, double, double, double); // Set sales for quarters
    double getSales(int) const; // Get sales for a specific quarter
    static double getTotalSales(); // Get total sales
};

#endif
