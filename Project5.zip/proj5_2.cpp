#include <iostream>
#include <string>
using namespace std;

class Person {
private:
    string name;
    int age;

public:
    Person() : name(""), age(0) {} // Default constructor

    Person(string name1, int age1) {
        name = name1;
        age = age1;
    }

    int getAge() const { return age; }

    string getName() const { return name; }

    void setName(string name1) {
        name = name1;
    }

    void setAge(int age1) {
        age = age1;
    }
};

// Prototypes
int lengthOfName(Person *p);

int main() {
    int numPersons;
    cout << "Enter the number of persons to process: ";
    cin >> numPersons;

    // Dynamically allocate array of Person objects
    Person *personArray = new Person[numPersons];

    // Input loop
    for (int i = 0; i < numPersons; i++) {
        string name;
        int age;

        cout << "Enter name for person " << (i + 1) << ": ";
        cin.ignore(); // Clear input buffer
        getline(cin, name);

        cout << "Enter age for person " << (i + 1) << ": ";
        cin >> age;

        personArray[i].setName(name);
        personArray[i].setAge(age);
    }

    // Output loop
    for (int i = 0; i < numPersons; i++) {
        cout << "The name " << personArray[i].getName()
             << " has length " << lengthOfName(&personArray[i]) << endl;
    }

    // Clean up dynamically allocated array
    delete[] personArray;

    return 0;
}

// Returns the number of characters in a person's name
int lengthOfName(Person *p) {
    string name = p->getName();
    return name.length();
}
