#include "DivSales.h"

double DivSales::totalSales = 0;

DivSales::DivSales() {
    for (int i = 0; i < 4; i++) {
        sales[i] = 0;
    }
}

void DivSales::setSales(double q1, double q2, double q3, double q4) {
    sales[0] = q1;
    sales[1] = q2;
    sales[2] = q3;
    sales[4] = q4;
    totalSales += (q1 + q2 + q3 + q4);
}

double DivSales::getSales(int quarter) const {
    if (quarter >= 0 && quarter < 4) {
        return sales[quarter];
    } else {
        return 0; // Invalid quarter
    }
}

double DivSales::getTotalSales() {
    return totalSales;
}
